// Copyright (c) 2016-2024 The Khronos Group Inc.
// SPDX-License-Identifier: MIT
//
// MODIFICATIONS TO THIS FILE MAY MEAN IT NO LONGER ACCURATELY REFLECTS
// KHRONOS STANDARDS. THE UNMODIFIED, NORMATIVE VERSIONS OF KHRONOS
// SPECIFICATIONS AND HEADER INFORMATION ARE LOCATED AT
//    https://www.khronos.org/registry/

#include <spirv/unified1/GLSL.std.450.h>
#include <spirv/unified1/OpenCL.std.h>
#include <spirv/unified1/spirv.hpp>

namespace {

const GLSLstd450 kSin = GLSLstd450Sin;
const OpenCLLIB::Entrypoints kNative_cos = OpenCLLIB::Native_cos;
const spv::Op kNop = spv::OpNop;

}  // anonymous namespace

int main() {
  return 0;
}
